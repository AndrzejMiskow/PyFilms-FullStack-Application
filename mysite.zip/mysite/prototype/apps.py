from django.apps import AppConfig


class PrototypeConfig(AppConfig):
    name = 'prototype'
