import datetime
from django.db import models
from django.utils import timezone
# Create your models here.
class Movies(models.Model):
    movie_text = models.CharField(max_length=200)
    show_date = models.DateTimeField('preview date')

    def __str__(self):
        return self.movie_text

    def now_showing(self):
        return self.show_date >= timezone.now() - datetime.timedelta(days=1)

class Cinema(models.Model):
    movie = models.ForeignKey(Movies, on_delete=models.CASCADE)
    booking_stat = models.CharField(max_length=200)
    seats = models.IntegerField(default=0)
